package functionalinterface;

@FunctionalInterface
public interface FunctionInterfaceTest {
    void eat(String food);
}
